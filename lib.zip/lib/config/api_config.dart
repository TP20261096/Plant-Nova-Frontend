class ApiConfig {
  static const String openWeatherApiKey = '81e89f70cc69723ba46e12e7b8a9ab1e';
}